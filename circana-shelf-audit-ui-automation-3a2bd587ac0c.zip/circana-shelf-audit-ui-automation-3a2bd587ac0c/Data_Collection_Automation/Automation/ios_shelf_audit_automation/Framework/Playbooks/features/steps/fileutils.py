from config import home_path
class fileutils():
    def __init__(self):
        self.homePath = home_path
        self.log_reference_file_path = self.homePath  + '/logs/'
        self.future_test_case_result_file_name = self.log_reference_file_path + 'TestResults.txt'
        self.future_result_case_file_name = self.log_reference_file_path + 'FailedTestcases_Info.txt'

    def write_failure_and_error_to_outputfile(self, context=None, error=None):
        print("Inside write_failure_to_outputfile")
        print("future_result_case_file_name" + self.future_result_case_file_name)
        # print(str(context.JIRA) +'\t' + str(context.RequestID) +'\t'+ str(error) + "\n")
        file = open(self.future_result_case_file_name, "a")
        file.write("Failed before validating test cases" + "\n")
        file.close()

    # def write_successful_test_cases(self,context,JIRA, RequestID):
    #     print("success_write")
    #     file = open(self.future_test_case_result_file_name, "a")
    #     # file.write(str(context.JIRA) +'\t'+ str(context.request_id) +str("\tPassed\t") + "Successfully Executed." + "\n")
    #     file.write(JIRA + '\t' +RequestID +'\t'+str("\tPassed\t") + "Successfully Executed." + "\n")
    #     file.close()

