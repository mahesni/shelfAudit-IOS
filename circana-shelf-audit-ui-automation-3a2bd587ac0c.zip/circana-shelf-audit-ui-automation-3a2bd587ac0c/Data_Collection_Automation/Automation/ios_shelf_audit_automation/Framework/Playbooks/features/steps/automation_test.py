import time
import os
import sys
import threading, time
from config import *
from behave import given, when, then
from config import home_path
from selenium import webdriver
from appium import webdriver
from appium.options.android import UiAutomator2Options
from selenium.webdriver.common.by import By
import subprocess
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import re
import random
from appium import webdriver
# from appium.webdriver.common.touch_action import TouchAction
from selenium.webdriver.common.action_chains import ActionChains
from appium import webdriver
from appium.options.common.base import AppiumOptions
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.actions.action_builder import ActionBuilder
from selenium.webdriver.common.actions.pointer_input import PointerInput
from selenium.webdriver.common.actions import interaction



home_path = home_path + '/logs/'
Results = ResponseMessage = home_path + 'TestResultsDetails.txt'
Failed_results = home_path + 'FailedTestcases_info.txt'
Final_result = home_path + 'TestResults.txt'


@given('I open the data collection application')
def execute_monkey_command_to_open_application(context):
    # command = f"adb shell monkey -p com.iri.collection -c android.intent.category.LAUNCHER 1"
    # subprocess.run(command, shell=True, check=True)
    # desired_caps = {"automationName": "UiAutomator2", "platformName": "Android", "deviceName": "0J739301222179AE",
    #                 "newCommandTimeout": "3600", "noReset": True}
    # options = UiAutomator2Options().load_capabilities(desired_caps)
    # context.driver = webdriver.Remote("http://localhost:4723/wd/hub", options=options)
    # command = f"adb shell monkey -p com.iri.collection -c android.intent.category.LAUNCHER 1"
    # subprocess.run(command, shell=True, check=True)
    desired_caps = {"automationName": "UiAutomator2", "platformName": "Android", "deviceName": "0J739301222179AE",
                    "newCommandTimeout": "3600", "noReset": True}
    options = UiAutomator2Options().load_capabilities(desired_caps)
    context.driver = webdriver.Remote("http://localhost:4723/wd/hub", options=options)
    command = f"adb shell monkey -p com.circana.collection -c android.intent.category.LAUNCHER 1"
    subprocess.run(command, shell=True, check=True)


@then("I will fill Time Sheet Activity with Today's Start Date")
def Time_sheet(context, timeout =500):
    try:
        # action = TouchAction(context.driver)
        Start_time = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[2]/android.widget.RelativeLayout/android.widget.ImageView[1]")))
        Start_time.click()
        time.sleep(1)
        Select_time_sheet_from_drop_down = context.driver.find_element(By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout[2]/android.widget.ListView/android.widget.RelativeLayout[4]")
        Select_time_sheet_from_drop_down.click()
        time.sleep(1)
        plus_button = context.driver.find_element(By.XPATH, "//android.widget.ImageView[@resource-id = 'com.iri.collection:id/floatingActionButtonDrag']")
        plus_button.click()
        time.sleep(1)
        Select_Activity_Time = context.driver.find_element(By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.view.ViewGroup/android.widget.Spinner/android.widget.CheckedTextView")
        Select_Activity_Time.click()
        time.sleep(1)
        Select_Time_Worked = context.driver.find_element(By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.TextView")
        Select_Time_Worked.click()
        time.sleep(1)
        Select_start_date = context.driver.find_element(By.XPATH, '//android.widget.TextView[@resource-id = "com.iri.collection:id/startDate"]')
        Select_start_date.click()
        time.sleep(1)
        # action.tap(x=635, y=1035).perform()
        context.driver.tap([(635,1035)])
        time.sleep(1)
        Save = context.driver.find_element(By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.view.ViewGroup/android.widget.Button[2]")
        Save.click()
        time.sleep(1)
        Ok = context.driver.find_element(By.XPATH, '//android.widget.Button[@resource-id = "android:id/button1"]')
        Ok.click()
        Back = context.driver.find_element(By.XPATH, '//android.widget.ImageView[@resource-id = "com.iri.collection:id/actionBarLeftlImageView"]')
        Back.click()
        print("Completed Time_Sheet Activity")
    except TimeoutException:
        raise TimeoutException(f"Element with Xpath is not clickable")


@then("I will complete existing time_sheets if available")
def delete_time_sheets(context, timeout =500):
    # action = TouchAction(context.driver)
    Start_time = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                          "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[2]/android.widget.RelativeLayout/android.widget.ImageView[1]")))
    Start_time.click()
    time.sleep(1)
    Select_time_sheet_from_drop_down = context.driver.find_element(By.XPATH,
                                                                   "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout[2]/android.widget.ListView/android.widget.RelativeLayout[4]")
    Select_time_sheet_from_drop_down.click()
    time.sleep(1)
    plus_button = context.driver.find_element(By.XPATH,
                                              "//android.widget.ImageView[@resource-id = 'com.iri.collection:id/floatingActionButtonDrag']")
    plus_button.click()
    time.sleep(1)
    Yes = context.driver.find_element(By.XPATH, '//android.widget.Button[@resource-id = "android:id/button1"]')
    Yes.click()
    time.sleep(1)
    enter_end_date = context.driver.find_element(By.XPATH,'//android.widget.TextView[@resource-id = "com.iri.collection:id/endDate"]')
    enter_end_date.click()
    time.sleep(1)
    context.driver.tap([(635, 1035)])
    # action.tap(x=635, y=1035).perform()
    time.sleep(1)
    Save = context.driver.find_element(By.XPATH,
                                       "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.view.ViewGroup/android.widget.Button[2]")
    Save.click()
    time.sleep(1)
    Ok = context.driver.find_element(By.XPATH, '//android.widget.Button[@resource-id = "android:id/button1"]')
    Ok.click()
    time.sleep(1)
    Back = context.driver.find_element(By.XPATH,
                                       '//android.widget.ImageView[@resource-id = "com.iri.collection:id/actionBarLeftlImageView"]')
    Back.click()
    print("Completed Time_Sheet Activity")


@then("I will select random Display 8000 store")
def select_store(context, timeout=500):
    time.sleep(5)
    el2 = context.driver.find_element(by=AppiumBy.ID, value="com.circana.collection.beta:id/weekMangerSpinner")
    el2.click()
    time.sleep(3)
    el3 = context.driver.find_element(by=AppiumBy.XPATH,
                              value="(//android.widget.RelativeLayout[@resource-id=\"com.circana.collection.beta:id/rowItemContent\"])[4]")
    el3.click()

    time.sleep(2)
    el4 = context.driver.find_element(by=AppiumBy.ID, value="android:id/button1")
    el4.click()
    stores_xpaths = ["/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[1]/android.widget.RelativeLayout", "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout","/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[3]/android.widget.RelativeLayout", "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[4]/android.widget.RelativeLayout"]
    child_xpath = '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView'
    for i in stores_xpaths:
        stores = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, i )))
        stores.click()
        # stores = context.driver.find_element(By.XPATH, i)
        # stores.click()
        Text = context.driver.find_element(By.XPATH, child_xpath)
        T = str(Text.text)
        print(T)
        Y = "Display(8000)"
        if T != Y:
            stores = context.driver.find_element(By.XPATH, i)
            stores.click()
        if T == Y:
            found_display = context.driver.find_element(By.XPATH, child_xpath)
            found_display.click()
            break


@then("I will start recording Display Locations and Task Complete page validation")
def recording_displays(context, timeout=500):
    try:
        # action = TouchAction(context.driver)
        Con_Read_proceed = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.widget.Button")))
        Con_Read_proceed.click()
        time.sleep(5)
        Display_Count = 2
        a = 1
        Upc_count = 0
        execution_number = 0
        for i in range(Display_Count):
            Execution_number = i
            execution_number = Execution_number
            diaplay_count = int(i)
            file = open(Results, "a")
            sys.stdout = file
            print("TestCase Execution No:", i)
            first_location = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View")))
            first_location.click()
            if a >= 1:
                okay_lets_start = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[2]")))
                okay_lets_start.click()
                image_path = Testing_image_2
                os.startfile(image_path)
                a = a-1
            else:
                image_path_2 = Testing_image_4
                os.startfile(image_path_2)

            time.sleep(3)
            start_recording = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, '//android.widget.ImageView[@content-desc="Record"]')))
            start_recording.click()
            # time.sleep(10)
            # stop_recording = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "(//android.widget.ImageView[@content-desc='Record'])[2]")))
            # stop_recording.click()
            time.sleep(25)
            Failed_count = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.widget.TextView")))
            # Special_product = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.HorizontalScrollView/android.view.View[2]/android.widget.TextView")))
            Value = str(Failed_count.text)
            # Value_2 = str(Special_product.text)
            # print(Value_2)
            number = re.findall(r'\d+', Value)
            # number_2 = re.findall(r'\d+', Value_2)
            value = [int(num) for num in number]
            # value_2 = [int(num) for num in number_2]
            failed_count = int(value[0])
            # special_product_count = int(value_2[0])
            # print(failed_count,"rrrrrrrr")
            automation_total_upc_count = Upc_count + failed_count
            Upc_count = automation_total_upc_count
            # print(automation_total_upc_count,"rrrfffff")
            Upc_number = []
            time.sleep(3)
            if diaplay_count == 2:
                Upc_count = Upc_count - failed_count
                Upc_count = Upc_count + 1
                image_path_2 = Barcode_image
                os.startfile(image_path_2)
            for i in range(failed_count):
                timeout= 500
                if diaplay_count != 2:
                    random_number = random.randint(100001, 999999)
                    Random_number = str(random_number)
                    Upc_number.append(Random_number)
                    # print("hahaha",Upc_number)
                    Barcode_xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText"
                    scan_barcode = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "(//android.view.View[@content-desc='Add'])[1]")))
                    scan_barcode.click()
                    Barcode = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText")))
                    Barcode.send_keys(Random_number)
                    send_code = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText/android.view.View/android.widget.Button")))
                    send_code.click()
                if diaplay_count == 2:
                    scan_barcode = WebDriverWait(context.driver, timeout).until(
                        EC.element_to_be_clickable((By.XPATH, "(//android.view.View[@content-desc='Add'])[1]")))
                    scan_barcode.click()
            formatted_number = [str(num).zfill(12) for num in Upc_number]
            file = open(Results, "a")
            sys.stdout = file
            print("UPC values :", formatted_number)
            # Special product validation code starts
            Special_product = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[2]/android.widget.TextView")))
            Value_2 = str(Special_product.text)
            # print(Value_2)
            number_2 = re.findall(r'\d+', Value_2)
            value_2 = [int(num) for num in number_2]
            special_product_count = int(value_2[0])
            file = open(Results, "a")
            sys.stdout = file
            print("Special Product Count: ", special_product_count)
            if special_product_count != 0:
                time.sleep(5)
                sp = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[2]/android.widget.TextView")))
                sp.click()
                Add_info = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View[3]/android.widget.Button")))
                Add_info.click()
                Display_inventory = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.ScrollView/android.widget.EditText")))
                Display_inventory.send_keys("10")
                Submit = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.widget.Button")))
                Submit.click()
                capture_next_display = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[5]")))
                capture_next_display.click()
                file = open(Final_result, "a")
                sys.stdout = file
                print("TestCase Number: ", execution_number, "Passed Successfully Executed")
            else:
                capture_next_display = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[5]")))
                capture_next_display.click()
                file = open(Final_result, "a")
                sys.stdout = file
                print("TestCase Number: ", execution_number, "Passed Successfully Executed")

        # Task complete validation starts from here
        first_display_count = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                                       "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View/android.widget.TextView[2]")))
        display_count = str(first_display_count.text)
        # print(display_count)
        number_2 = re.findall(r'\d+', display_count)
        value_2 = [int(num) for num in number_2]
        display_countt = int(value_2[0])
        # print(display_countt)
        Task_complete = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                                 "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[3]")))
        Task_complete.click()

        Total_count = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                               "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout[3]/android.widget.LinearLayout/android.widget.TextView[2]")))
        total_count = str(Total_count.text)
        # print(total_count)
        number_2 = re.findall(r'\d+', total_count)
        value_2 = [int(num) for num in number_2]
        total_countt = int(value_2[0])
        # print(total_countt)
        Total_upc_count = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                                   "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout[2]/android.widget.LinearLayout/android.widget.TextView[2]")))
        total_count = str(Total_upc_count.text)
        # print(total_count)
        number_3 = re.findall(r'\d+', total_count)
        value_3 = [int(num) for num in number_3]
        total_upc_countt = int(value_3[0])
        file = open(Results, "a")
        sys.stdout = file
        print("Total UPC Count: ",total_upc_countt)
        if str(display_countt) == str(total_countt) and str(total_upc_countt) == str(Upc_count):
            file = open(Results, "a")
            sys.stdout = file
            print("Event count and upc_count is matching with Display Location counts", "Display Count : ", str(display_countt),
                  "Event Count : ", str(total_countt),"Expected Upc Count : ", str(total_upc_countt),
                  "Event Count : ", str(Upc_count))
        else:
            file = open(Failed_results, "a")
            sys.stdout = file
            print("Event count and upc_count is not  matching with Display Location counts", "Display Count : ", str(display_countt),
                  "Event Count : ", str(total_countt), "Expected Upc Count : ", str(total_upc_countt),
                  "Event Count : ", str(Upc_count))

    except TimeoutException:
        raise TimeoutException(f"Element with Xpath is not clickable")


@then("I will scroll the display location to left and select View Captures")
def scroll_left(context, timeout=500):
    store_location_xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View"
    display_xpath = WebDriverWait(context.driver, timeout).until(
        EC.element_to_be_clickable((By.XPATH, store_location_xpath)))
    start_x = display_xpath.location['x'] + (display_xpath.size['width'] // 2)  # Center of the text box
    start_y = display_xpath.location['y'] + (display_xpath.size['height'] // 2)
    end_x = start_x - 200  # Adjust the value to set how far left you want to move
    end_y = start_y
    # action = TouchAction(context.driver)
    # action.press(x=start_x, y=start_y).wait(500).move_to(x=end_x, y=end_y).release().perform()
    context.driver.swipe(x=start_x, y=start_y).wait(500).move_to(x=end_x, y=end_y).release().perform()

@then("Get the random number from 100001 to 999999")
def random_upc (context):
    # Generate a random number between 100001 and 999999
    random_number = random.randint(100001, 999999)

    print(f"Random number: {random_number}")


# @then("I will do Task Complete and validate the attributes")
# def task_complete(context, timeout=500):
#     first_display_count = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View/android.widget.TextView[2]")))
#     display_count = str(first_display_count.text)
#     print(display_count)
#     number_2 = re.findall(r'\d+', display_count)
#     value_2 = [int(num) for num in number_2]
#     display_countt = int(value_2[0])
#     print(display_countt)
#     Task_complete =  WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[3]")))
#     Task_complete.click()
#
#     Total_count = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout[3]/android.widget.LinearLayout/android.widget.TextView[2]")))
#     total_count = str(Total_count.text)
#     print(total_count)
#     number_2 = re.findall(r'\d+', total_count)
#     value_2 = [int(num) for num in number_2]
#     total_countt = int(value_2[0])
#     print(total_countt)
#     total_countt = 2
#     Total_upc_count = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout[2]/android.widget.LinearLayout/android.widget.TextView[2]")))
#     total_count = str(Total_upc_count.text)
#     print(total_count)
#     number_3 = re.findall(r'\d+', total_count)
#     value_3 = [int(num) for num in number_3]
#     total_upc_countt = int(value_3[0])
#     print(total_upc_countt)
#     total_countt = 2
#
#     if str(display_countt) == str(total_countt) and str(total_upc_countt) == U:
#         file = open(Results, "a")
#         sys.stdout = file
#         print("Event count is matching with Display Location count: ", "Display Count : ", str(display_countt), "Event Count : ", str(total_countt))
#     else:
#         file = open(Failed_results, "a")
#         sys.stdout = file
#         print("Event count is not  matching with Display Location count: ", "Display Count : ", str(display_countt),
#               "Event Count : ", str(total_countt))



@then("I will delete one recoding data from display location and verify the QC screen Event Count attributes")
def delete_recording(context, timeout=500):
    back_from_QC = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[2]/android.widget.RelativeLayout/android.widget.ImageView[1]")))
    back_from_QC.click()
    # store_location_xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View"
    # display_xpath = WebDriverWait(context.driver, timeout).until(
    #     EC.element_to_be_clickable((By.XPATH, store_location_xpath)))
    # start_x = display_xpath.location['x'] + (display_xpath.size['width'] // 2)  # Center of the text box
    # start_y = display_xpath.location['y'] + (display_xpath.size['height'] // 2)
    # end_x = start_x - 200  # Adjust the value to set how far left you want to move
    # end_y = start_y
    # action = TouchAction(context.driver)
    # action.press(x=start_x, y=start_y).wait(500).move_to(x=end_x, y=end_y).release().perform()
    store_location_xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View"
    display_xpath = WebDriverWait(context.driver,timeout).until(
        EC.element_to_be_clickable((By.XPATH, store_location_xpath)))

    # Start coordinates
    start_x = display_xpath.location['x'] + (display_xpath.size['width'] // 2)
    start_y = display_xpath.location['y'] + (display_xpath.size['height'] // 2)

    # Calculate end coordinates
    end_x = start_x - 200  # Adjust the value to set how far left you want to move
    end_y = start_y

    # Initialize ActionChains
    actions = ActionChains(context.driver)

    # Perform the swipe action (click and drag)
    actions.move_to_element_with_offset(display_xpath, 0, 0)
    actions.click_and_hold()  # Press down
    actions.move_by_offset(end_x - end_y ,0)  # Move by offset
    actions.release()  # Release the press
    actions.perform()
    view_capture = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.widget.Button")))
    view_capture.click()
    select_first_Capture = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]")))
    select_first_Capture.click()
    Delete = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, '//android.widget.ImageView[@content-desc="Delete"]')))
    Delete.click()
    Yes_Delete = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, '/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.View/android.view.View/android.view.View/android.view.View')))
    Yes_Delete.click()
    back = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, '//android.widget.ImageView[@content-desc="Back"]')))
    back.click()

    # Task complete validation starts from here
    first_display_count = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                                   "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View/android.widget.TextView[2]")))
    display_count = str(first_display_count.text)
    # print(display_count)
    number_2 = re.findall(r'\d+', display_count)
    value_2 = [int(num) for num in number_2]
    display_countt = int(value_2[0])
    # print(display_countt)
    Task_complete = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                             "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[3]")))
    Task_complete.click()

    Total_count = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                           "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout[3]/android.widget.LinearLayout/android.widget.TextView[2]")))
    total_count = str(Total_count.text)
    # print(total_count)
    number_2 = re.findall(r'\d+', total_count)
    value_2 = [int(num) for num in number_2]
    total_countt = int(value_2[0])
    # print(total_countt)
    # Total_upc_count = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
    #                                                                                            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout[2]/android.widget.LinearLayout/android.widget.TextView[2]")))
    # total_count = str(Total_upc_count.text)
    # print(total_count)
    # number_3 = re.findall(r'\d+', total_count)
    # value_3 = [int(num) for num in number_3]
    # total_upc_countt = int(value_3[0])
    # file = open(Results, "a")
    # sys.stdout = file
    # print("Total UPC Count: ", total_upc_countt)
    if str(display_countt) == str(total_countt):
        file = open(Results, "a")
        sys.stdout = file
        print("Successfully matching Event Count After deleting recordings from Display Locations ", "Display Count : ",
              str(display_countt),"Event Count : ", str(total_countt))
    else:
        file = open(Failed_results, "a")
        sys.stdout = file
        print("Failed matching found for Event Count After deleting recordings from Display Location", "Display Count : ",
              str(display_countt))

@then("I will validate deleting UPC items from success tab and verify the counts,upc values")
def del_success_upc(context, timeout=500):

    time.sleep(5)
    Upc_count = 0
    back_from_QC = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[2]/android.widget.RelativeLayout/android.widget.ImageView[1]")))
    back_from_QC.click()
    time.sleep(5)
    first_location = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                              "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View")))
    first_location.click()
    okay_lets_start = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                               "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[2]")))
    okay_lets_start.click()
    image_path = Testing_image_2
    os.startfile(image_path)
    time.sleep(3)
    start_recording = WebDriverWait(context.driver, timeout).until(
        EC.element_to_be_clickable((By.XPATH, '//android.widget.ImageView[@content-desc="Record"]')))
    start_recording.click()
    # time.sleep(10)
    # stop_recording = WebDriverWait(context.driver, timeout).until(
    #     EC.element_to_be_clickable((By.XPATH, "(//android.widget.ImageView[@content-desc='Record'])[2]")))
    # stop_recording.click()
    time.sleep(15)
    Failed_count = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                            "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.widget.TextView")))
    # Special_product = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.HorizontalScrollView/android.view.View[2]/android.widget.TextView")))
    Value = str(Failed_count.text)
    # Value_2 = str(Special_product.text)
    # print(Value_2)
    number = re.findall(r'\d+', Value)
    # number_2 = re.findall(r'\d+', Value_2)
    value = [int(num) for num in number]
    # value_2 = [int(num) for num in number_2]
    failed_count = int(value[0])
    # special_product_count = int(value_2[0])
    # print(failed_count)
    automation_total_upc_count = Upc_count + failed_count
    Upc_count = automation_total_upc_count
    # print(automation_total_upc_count)
    Upc_number = []
    time.sleep(3)
    for i in range(failed_count):
        random_number = random.randint(100001, 999999)
        Random_number = str(random_number)
        Upc_number.append(Random_number)

        # Barcode_xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText"
        Barcode_xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText"
        scan_barcode = WebDriverWait(context.driver, timeout).until(
            EC.element_to_be_clickable((By.XPATH, "(//android.view.View[@content-desc='Add'])[1]")))
        scan_barcode.click()
        Barcode = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                           "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText")))
        Barcode.send_keys(Random_number)
        send_code = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                             "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText/android.view.View/android.widget.Button")))
        send_code.click()
    success_tab = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                         "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[3]")))
    success_tab.click()
    SucessCount = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                             "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[3]/android.widget.TextView")))
    success_count = str(SucessCount.text)
    print("success:",success_count)
    number_2 = re.findall(r'\d+', success_count)
    value_2 = [int(num) for num in number_2]
    sucess_count_before_deleting = int(value_2[0])
    print("SUcesss count", sucess_count_before_deleting)
    formatted_number = [str(num).zfill(12) for num in Upc_number]
    # file = open(Results, "a")
    # sys.stdout = file
    print("UPC values :", formatted_number)
    v = 1
    Success_upc_values = []
    Scccess_upc_values2 = []
    # Scrolling fist UPC left to delete
    upc_barcodes_value = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                                  f"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.widget.TextView[2]")))
    UPC_Value = str(upc_barcodes_value.text)
    Success_upc_values.append(UPC_Value)
    first_success_xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]"
    display_xpath = WebDriverWait(context.driver, timeout).until(
        EC.element_to_be_clickable((By.XPATH, first_success_xpath)))
    start_x = display_xpath.location['x'] + (display_xpath.size['width'] // 2)
    start_y = display_xpath.location['y'] + (display_xpath.size['height'] // 2)
    # Calculate end coordinates
    end_x = start_x - 200  # Adjust the value to set how far left you want to move
    end_y = start_y
    # Initialize ActionChains
    actions = ActionChains(context.driver)
    # Perform the swipe action (click and drag)
    actions.move_to_element_with_offset(display_xpath, 0, 0)
    actions.click_and_hold()  # Press down
    actions.move_by_offset(end_x - end_y, 0)  # Move by offset
    actions.release()  # Release the press
    actions.perform()

    delete = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                           "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View[2]/android.widget.Button")))
    delete.click()
    SucessCount = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                           "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.HorizontalScrollView/android.view.View[3]/android.widget.TextView")))
    success_count = str(SucessCount.text)
    number_2 = re.findall(r'\d+', success_count)
    value_2 = [int(num) for num in number_2]
    sucess_count_after_deleting = int(value_2[0])
    print("SUcesss count after deleting", sucess_count_after_deleting)
    if sucess_count_after_deleting == sucess_count_before_deleting - 1 :
        file = open(Results, "a")
        sys.stdout = file
        print("Successfully deleted upc value and validated", "Before deleting upc Count : ",
              str(sucess_count_before_deleting),"After deleting upc Count : ", str(sucess_count_after_deleting))

    else:
        file = open(Failed_results, "a")
        sys.stdout = file
        print("failed to deleted upc value ", "Before deleting upc Count : ",
              str(sucess_count_before_deleting), "After deleting upc Count : ", str(sucess_count_after_deleting))
        # capture_next_display = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
        #                                                                                                 "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]")))
        # capture_next_display.click()

    for i in range(sucess_count_before_deleting):
        if i >= 1:
            upc_barcodes_value = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                                   f"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.widget.TextView[2]")))
            UPC_Value = str(upc_barcodes_value.text)
            v = v+1
            Success_upc_values.append(UPC_Value)
            # print("uuuu",UPC_Value)
            print(Success_upc_values)
            first_success_xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]"
            display_xpath = WebDriverWait(context.driver, timeout).until(
                EC.element_to_be_clickable((By.XPATH, first_success_xpath)))
            start_x = display_xpath.location['x'] + (display_xpath.size['width'] // 2)  # Center of the text box
            start_y = display_xpath.location['y'] + (display_xpath.size['height'] // 2)
            end_x = start_x - 200  # Adjust the value to set how far left you want to move
            end_y = start_y
            # Initialize ActionChains
            actions = ActionChains(context.driver)
            # Perform the swipe action (click and drag)
            actions.move_to_element_with_offset(display_xpath, 0, 0)
            actions.click_and_hold()  # Press down
            actions.move_by_offset(end_x - end_y, 0)  # Move by offset
            actions.release()  # Release the press
            actions.perform()
            # action = TouchAction(context.driver)
            # action.press(x=start_x, y=start_y).wait(500).move_to(x=end_x, y=end_y).release().perform()
            delete = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
                                                                                              "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View[2]/android.widget.Button")))
            delete.click()
    for barcode in Success_upc_values:
        barcode_number = barcode.split(": ")[1]
        Scccess_upc_values2.append(barcode_number)
    print(Scccess_upc_values2)
    if sorted(formatted_number) == sorted(Scccess_upc_values2):
        file = open(Results, "a")
        sys.stdout = file
        print("Success tab UPC values are matching with automation generated values")
    else:
        file = open(Failed_results, "a")
        sys.stdout = file
        print("Failed to match success tab UPC values with automation generated values")
    # capture_next_display = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH,
    #                                                                                                 "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]")))
    # capture_next_display.click()
    more_options = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, '//android.widget.ImageView[@content-desc="More Options"]')))
    more_options.click()
    delete_capture_data = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, '/hierarchy/android.view.ViewGroup/android.view.View/android.view.View/android.view.View[2]/android.view.View[3]')))
    delete_capture_data.click()
    yes_delete = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, '/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.View/android.view.View/android.view.View/android.view.View')))
    yes_delete.click()



@given("I will open the shelf audit application")
def open_application(context):
    options = AppiumOptions()
    options.load_capabilities({
        "appium:newCommandTimeout": 3600,
        "appium:connectHardwareKeyboard": True,
        "appium:automationName": "xcuitest",
        "appium:platformVersion": "18.5",
        "appium:platformName": "ios",
        "appium:deviceName": "iPhone 13",
        "appium:bundleId": "org.circana.ShelfAuditNativeApp.Beta",  # Messages app
        "appium:udid": "00008110-001948AA0161801E",
        "headspin:controlLock": True
    })
    context.driver = webdriver.Remote(
        head_spin_url,
        options=options
    )

    def _keep_alive():
        while True:
            try:
                context.driver.execute_script("mobile: deviceInfo", {})  # lightweight heartbeat
            except:
                break
            time.sleep(30)  # ping every 30s

    threading.Thread(target=_keep_alive, daemon=True).start()
@then("I will select Display 8000 store")
def store_selection(context,timeout=500):
    time.sleep(3)
    el2 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                              value="**/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeCollectionView/XCUIElementTypeCell[3]/XCUIElementTypeOther/XCUIElementTypeOther")
    el2.click()
    time.sleep(3)
    el3 = context.driver.find_element(by=AppiumBy.ACCESSIBILITY_ID, value="Yes")
    el3.click()
    stores_xpaths = [
        "//XCUIElementTypeWindow/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[1]",
        "//XCUIElementTypeWindow/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[2]",
        "//XCUIElementTypeWindow/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[3]",
        "//XCUIElementTypeWindow/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[4]"]
    child_xpath = '//XCUIElementTypeStaticText[@name="Display(8000)"]'
    for i in stores_xpaths:
        stores = WebDriverWait(context.driver, timeout).until(EC.element_to_be_clickable((By.XPATH, i)))
        stores.click()
        # stores = context.driver.find_element(By.XPATH, i)
        # stores.click()
        Text = context.driver.find_element(By.XPATH, child_xpath)
        T = str(Text.text)
        print(T)
        Y = "Display(8000)"
        if T != Y:
            stores = context.driver.find_element(By.XPATH, i)
            stores.click()
        if T == Y:
            found_display = context.driver.find_element(By.XPATH, child_xpath)
            found_display.click()
            break
@then("I will do actual validation")
def confirm(context, timeout=500, runs=10):
    # requires: import time, re, random
    time.sleep(5)
    # Confirm Reading & Proceed button
    Con_Read_proceed = WebDriverWait(context.driver, timeout).until(
        EC.element_to_be_clickable((By.XPATH, '//XCUIElementTypeButton[@name="Confirm Reading & Proceed"]'))
    )
    Con_Read_proceed.click()
    Upc_count = 0
    try:
        for attempt in range(runs):
            actions = ActionChains(context.driver)
            touch = PointerInput("touch", "default")
            actions.w3c_actions = ActionBuilder(context.driver, mouse=touch)

            actions.w3c_actions.pointer_action.move_to_location(360, 100)
            actions.w3c_actions.pointer_action.pointer_down()
            actions.w3c_actions.pointer_action.pointer_up()
            actions.perform()
            print(f"\n======= Starting run {attempt + 1}/{runs} =======")

            # -------- Perform actions ONCE to reach counts screen --------
            loby = WebDriverWait(context.driver, timeout).until(
                EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                    "**/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther/"
                    "XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/"
                    "XCUIElementTypeTable/XCUIElementTypeCell[1]"))
            )
            loby.click()

            air = WebDriverWait(context.driver, timeout).until(
                EC.element_to_be_clickable((AppiumBy.ACCESSIBILITY_ID,
                    "Automatic Image Recognition, Use this option to automatically capture the display"))
            )
            air.click()

            Select_image = WebDriverWait(context.driver, timeout).until(
                EC.element_to_be_clickable((AppiumBy.ACCESSIBILITY_ID, "photo.artframe"))
            )
            Select_image.click()

            time.sleep(2)

            image_index = attempt + 1

            select_image_xpath = f'**/XCUIElementTypeImage[`name == "PXGGridLayout-Info"`][{image_index}]'

            select_image = WebDriverWait(context.driver, timeout).until(
                EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN, select_image_xpath))
            )
            select_image.click()
            time.sleep(25)

            # -------- Now only loop on counts --------
            while True:
                # Failed count
                Failed_count = WebDriverWait(context.driver, timeout).until(
                    EC.presence_of_element_located((By.XPATH, "//XCUIElementTypeStaticText[starts-with(@name, 'Failed')]"))
                )
                failed_count = int(re.findall(r'\d+', Failed_count.text)[0])
                print(f"Failed count: {failed_count}")

                # Success count
                Sucess_count = WebDriverWait(context.driver, timeout).until(
                    EC.presence_of_element_located((By.XPATH, "//XCUIElementTypeStaticText[starts-with(@name, 'Success')]"))
                )
                success_count = int(re.findall(r'\d+', Sucess_count.text)[0])
                print(f"Success count: {success_count}")

                # Special products count
                Special_count_element = WebDriverWait(context.driver, timeout).until(
                    EC.presence_of_element_located((By.XPATH, "//XCUIElementTypeStaticText[starts-with(@name, 'Special Product')]"))
                )
                Special_count = int(re.findall(r'\d+', Special_count_element.text)[0])
                print(f"Special count: {Special_count}")

                # Update failed UPC count
                # Upc_count += failed_count
                # time.sleep(3)

                # --- loop control ---
                if Special_count > 0:
                    print("🔄 Special count still > 0, processing special item...")
                    el1 = WebDriverWait(context.driver, timeout).until(
                        EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                            "**/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther/"
                            "XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/"
                            "XCUIElementTypeCollectionView/XCUIElementTypeCell[2]/XCUIElementTypeOther/XCUIElementTypeOther"))
                    )
                    el1.click()

                    el2 = WebDriverWait(context.driver, timeout).until(
                        EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                            "**/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther/"
                            "XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/"
                            "XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeButton[2]"))
                    )
                    el2.click()
                    try:
                        display_type = None
                        display_type_2 = None

                        # --- Check for Display Type ---
                        try:
                            display_type = WebDriverWait(context.driver, 3).until(
                                EC.presence_of_element_located(
                                    (By.XPATH, '//XCUIElementTypeStaticText[@name="Display Type"]')
                                )
                            )
                            print("📌 Display Type is available")
                        except TimeoutException:
                            pass

                        # --- Check for Units Deep ---
                        try:
                            display_type_2 = WebDriverWait(context.driver, 3).until(
                                EC.presence_of_element_located(
                                    (By.XPATH, '//XCUIElementTypeStaticText[@name="Units Deep"]')
                                )
                            )
                            print("📌 Units Deep is available")
                        except TimeoutException:
                            pass
                        # --- Decision Branching ---
                        if display_type and not display_type_2:
                            print("▶ Running flow for Display Type only")

                            el1 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.CLASS_NAME, "XCUIElementTypeTextField"))
                            )
                            el1.click()

                            el2 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                                                            '**/XCUIElementTypeButton[`name == "1"`]'))
                            )
                            el2.click()

                            el3 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                                                            '**/XCUIElementTypeStaticText[`name == "Done"`]'))
                            )
                            el3.click()

                            el4 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                                                            "**/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther/"
                                                            "XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/"
                                                            "XCUIElementTypeOther[2]/XCUIElementTypeScrollView/XCUIElementTypeOther[1]/"
                                                            "XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton"))
                            )
                            el4.click()

                            el5 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.ACCESSIBILITY_ID, "Done"))
                            )
                            el5.click()

                            el16 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                                                               value="**/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther/"
                                                                     "XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/"
                                                                     "XCUIElementTypeOther[2]/XCUIElementTypeScrollView/XCUIElementTypeOther[1]/"
                                                                     "XCUIElementTypeOther[3]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText[2]")
                            el16.click()

                            el7 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.ACCESSIBILITY_ID, "Done"))
                            )
                            el7.click()

                            el8 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                                                            "**/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther/"
                                                            "XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/"
                                                            "XCUIElementTypeOther[2]/XCUIElementTypeScrollView/XCUIElementTypeOther[1]/"
                                                            "XCUIElementTypeOther[4]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText[2]"))
                            )
                            el8.click()

                            el9 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.ACCESSIBILITY_ID, "Done"))
                            )
                            el9.click()

                            el10 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                                                            '**/XCUIElementTypeButton[`name == "Submit"`]'))
                            )
                            el10.click()

                        elif display_type and display_type_2:
                            print("▶ Running flow for Display Type + Units Deep")

                            el1 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                                                              value="**/XCUIElementTypeTextField[`value == \"Enter Facings\"`]")
                            el1.click()

                            el2 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                                                              value="**/XCUIElementTypeButton[`name == \"1\"`]")
                            el2.click()

                            el3 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                                                              value="**/XCUIElementTypeStaticText[`name == \"Done\"`]")
                            el3.click()

                            el4 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                                                              value="**/XCUIElementTypeTextField[`value == \"Enter Units Deep\"`]")
                            el4.click()

                            el5 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                                                              value="**/XCUIElementTypeButton[`name == \"1\"`]")
                            el5.click()

                            el6 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                                                              value="**/XCUIElementTypeStaticText[`name == \"Done\"`]")
                            el6.click()

                            el7 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                                                              value="**/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther/"
                                                                    "XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/"
                                                                    "XCUIElementTypeOther[2]/XCUIElementTypeScrollView/XCUIElementTypeOther[1]/"
                                                                    "XCUIElementTypeOther[3]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText[2]")
                            el7.click()

                            el8 = context.driver.find_element(by=AppiumBy.ACCESSIBILITY_ID, value="Done")
                            el8.click()

                            el9 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                                                              value="**/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther/"
                                                                    "XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/"
                                                                    "XCUIElementTypeOther[2]/XCUIElementTypeScrollView/XCUIElementTypeOther[1]/"
                                                                    "XCUIElementTypeOther[4]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText[2]")
                            el9.click()

                            el10 = context.driver.find_element(by=AppiumBy.ACCESSIBILITY_ID, value="Done")
                            el10.click()

                            el11 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                                                               value="**/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther/"
                                                                     "XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/"
                                                                     "XCUIElementTypeOther[2]/XCUIElementTypeScrollView/XCUIElementTypeOther[1]/"
                                                                     "XCUIElementTypeOther[5]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText[2]")
                            el11.click()

                            el12 = context.driver.find_element(by=AppiumBy.ACCESSIBILITY_ID, value="Done")
                            el12.click()

                            el13 = context.driver.find_element(by=AppiumBy.IOS_CLASS_CHAIN,
                                                               value="**/XCUIElementTypeButton[`name == \"Submit\"`]")
                            el13.click()

                        else:
                            print("⚠ Display Type not available → Running short flow")

                            el3 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.CLASS_NAME, "XCUIElementTypeTextField"))
                            )
                            el3.click()

                            el4 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                                                            '**/XCUIElementTypeButton[`name == "1"`]'))
                            )
                            el4.click()

                            el6 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                                                            '**/XCUIElementTypeStaticText[`name == "Done"`]'))
                            )
                            el6.click()

                            el7 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                                                            '**/XCUIElementTypeButton[`name == "Submit"`]'))
                            )
                            el7.click()
                    except Exception as e:
                        print(f"❌ Unexpected error: {e}")

                    continue

                # Special count == 0
                print("✅ Special count reached 0")
                if success_count > 0:
                    el1 = WebDriverWait(context.driver, timeout).until(
                        EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                            '**/XCUIElementTypeButton[`name == "Task Complete"`]'))
                    )
                    el1.click()

                    continue_btn = WebDriverWait(context.driver, timeout).until(
                        EC.element_to_be_clickable((By.XPATH, '//XCUIElementTypeButton[@name="Continue"]'))
                    )
                    continue_btn.click()
                    break  # end this run, go to next attempt

                # success_count == 0 -> run failed_count loop
                print("⚠ Success count is 0, running failed_count loop...")
                random_number = random.randint(100001, 999999)
                Random_number = str(random_number)

                el1 = WebDriverWait(context.driver, timeout).until(
                    EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                        "**/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther/"
                        "XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/"
                        "XCUIElementTypeCollectionView/XCUIElementTypeCell[1]/XCUIElementTypeOther/XCUIElementTypeOther"))
                )
                el1.click()

                el2 = WebDriverWait(context.driver, timeout).until(
                    EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                        '**/XCUIElementTypeButton[`name == "Scan"`][1]'))
                )
                el2.click()
                el3 = WebDriverWait(context.driver, timeout).until(
                    EC.element_to_be_clickable((AppiumBy.CLASS_NAME, "XCUIElementTypeTextField"))
                )
                el3.send_keys(Random_number)

                el4 = WebDriverWait(context.driver, timeout).until(
                    EC.element_to_be_clickable((AppiumBy.ACCESSIBILITY_ID, "send"))
                )
                el4.click()
                # Poll until success achieved
                while success_count == 0:
                    Sucess_count = WebDriverWait(context.driver, timeout).until(
                        EC.presence_of_element_located((By.XPATH, "//XCUIElementTypeStaticText[starts-with(@name, 'Success')]"))
                    )
                    success_count = int(re.findall(r'\d+', Sucess_count.text)[0])
                    print(f"Retry success check: {success_count}")
                    if success_count > 0:
                        print("✅ Success finally achieved.")
                        el_done = WebDriverWait(context.driver, timeout).until(
                            EC.element_to_be_clickable((AppiumBy.IOS_CLASS_CHAIN,
                                '**/XCUIElementTypeButton[`name == "Task Complete"`]'))
                        )
                        el_done.click()

                        continue_btn = WebDriverWait(context.driver, timeout).until(
                            EC.element_to_be_clickable((By.XPATH, '//XCUIElementTypeButton[@name="Continue"]'))
                        )
                        continue_btn.click()
                        break
                    else:
                        print("❌ Still no success, retrying...")
                break  # end this run after success path

    except Exception as e:
        print("Error in confirm():", str(e))




@given("I will open Android the shelf audit application")
def open_headspin_android(context):
    options = AppiumOptions()
    options.load_capabilities({
        "appium:automationName": "uiautomator2",
        "appium:platformName": "Android",
        "appium:deviceName": "SM-S906U1",
        "appium:udid": "RFCT32XYLLV",  # HeadSpin UDID
        "appium:noReset": True,         # don’t clear data
        "appium:fullReset": False,      # don’t reinstall app
        "headspin:controlLock": True,
        "appium:appPackage": "com.circana.collection.beta",
        "appium:appActivity": "com.circana.collection.ui.activities.PermissionCheckActivity"
    })

    # Connect to HeadSpin Appium hub
    driver = webdriver.Remote(
        "https://dev-us-sny-8.headspin.io:7010/v0/2c48a91cfdd14d30864178f07e665e90/wd/hub",
        options=options
    )

    # Wait for device to be ready and unlock if needed
    time.sleep(5)  # small delay to stabilize connection
    try:
        if driver.is_locked():
            driver.unlock()
            print("Device was locked, unlocked successfully.")
        else:
            print("Device already unlocked.")
    except Exception as e:
        print(f"Warning: Could not check/unlock device: {e}")

    # Ensure app is in foreground
    try:
        driver.activate_app("com.circana.collection.beta")
        print("App activated successfully.")
    except Exception as e:
        print(f"Warning: Could not activate app: {e}")

    # Small wait to ensure app is ready
    time.sleep(5)

    # Save driver in context for later use
    context.driver = driver
    print("✅ HeadSpin Android session started successfully.")









@then("I will do actual validation for Android")
def confirm_android(context, timeout=500, runs=10):
    time.sleep(5)

    # ✅ Confirm Reading & Proceed button
    confirm = WebDriverWait(context.driver, timeout).until(
        EC.element_to_be_clickable((By.CLASS_NAME, "android.widget.Button"))
    )
    confirm.click()

    try:
        for attempt in range(runs):
            print(f"\n======= Starting run {attempt + 1}/{runs} =======")

            # ✅ Tap at coordinates (360, 100)
            actions = ActionChains(context.driver)
            touch = PointerInput("touch", "default")
            actions.w3c_actions = ActionBuilder(context.driver, mouse=touch)
            actions.w3c_actions.pointer_action.move_to_location(360, 100)
            actions.w3c_actions.pointer_action.pointer_down()
            actions.w3c_actions.pointer_action.pointer_up()
            actions.perform()

            # ✅ Select first item in list
            loby = WebDriverWait(context.driver, timeout).until(
                EC.element_to_be_clickable((By.XPATH,
                    '//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.view.View'))
            )
            loby.click()

            # ✅ Automatic Image Recognition button
            el1 = WebDriverWait(context.driver, timeout).until(
                EC.element_to_be_clickable((By.XPATH,
                    "//android.view.ViewGroup/android.view.View/android.view.View/android.view.View[1]"))
            )
            el1.click()

            time.sleep(5)
            actions = ActionChains(context.driver)
            actions.w3c_actions = ActionBuilder(context.driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
            actions.w3c_actions.pointer_action.move_to_location(482, 1082)
            actions.w3c_actions.pointer_action.pointer_down()
            actions.w3c_actions.pointer_action.pause(0.1)
            actions.w3c_actions.pointer_action.release()
            actions.perform()

            # ✅ Select Gallery
            el5 = WebDriverWait(context.driver, timeout).until(
                EC.element_to_be_clickable((AppiumBy.ACCESSIBILITY_ID, "Gallery"))
            )
            el5.click()
            time.sleep(2)

            # ✅ Select PXGGridLayout-Info image
            image_index = attempt + 1
            select_image_xpath = (
                f"//androidx.compose.ui.platform.ComposeView/android.view.View/"
                f"android.view.View/android.view.View[5]/android.view.View[{image_index}]/android.view.View[2]/android.view.View"
            )
            select_image = WebDriverWait(context.driver, timeout).until(
                EC.element_to_be_clickable((By.XPATH, select_image_xpath))
            )
            select_image.click()
            time.sleep(25)

            # ✅ Loop on counts
            while True:
                Failed_count = WebDriverWait(context.driver, timeout).until(
                    EC.presence_of_element_located((By.XPATH, "//android.widget.TextView[starts-with(@text,'Failed')]"))
                )
                failed_count = int(re.findall(r'\d+', Failed_count.text)[0])
                print(f"Failed count: {failed_count}")

                Sucess_count = WebDriverWait(context.driver, timeout).until(
                    EC.presence_of_element_located((By.XPATH, "//android.widget.TextView[starts-with(@text,'Success')]"))
                )
                success_count = int(re.findall(r'\d+', Sucess_count.text)[0])
                print(f"Success count: {success_count}")

                Special_count_element = WebDriverWait(context.driver, timeout).until(
                    EC.presence_of_element_located((By.XPATH, "//android.widget.TextView[starts-with(@text,'Special Product')]"))
                )
                Special_count = int(re.findall(r'\d+', Special_count_element.text)[0])
                print(f"Special count: {Special_count}")

                # ✅ Process Special Products
                if Special_count > 0:
                    print("🔄 Special count still > 0, processing special item...")

                    el1 = WebDriverWait(context.driver, timeout).until(
                        EC.element_to_be_clickable((By.XPATH, "//android.widget.TextView[starts-with(@text,'Special Product')]"))
                    )
                    el1.click()
                    time.sleep(3)
                    el2 = WebDriverWait(context.driver, timeout).until(
                        EC.element_to_be_clickable((By.XPATH,
                            "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[4]"))
                    )
                    el2.click()

                    # ✅ Display Type / Units Deep check
                    try:
                        display_type = None
                        display_type_2 = None

                        try:
                            display_type = WebDriverWait(context.driver, 3).until(
                                EC.presence_of_element_located(
                                    (By.XPATH, '//android.widget.TextView[@text="Display Type"]')
                                )
                            )
                            print("📌 Display Type is available")
                        except TimeoutException:
                            pass

                        try:
                            display_type_2 = WebDriverWait(context.driver, 3).until(
                                EC.presence_of_element_located(
                                    (By.XPATH, '//android.widget.TextView[@text="Units Deep"]')
                                )
                            )
                            print("📌 Units Deep is available")
                        except TimeoutException:
                            pass

                        # ✅ Branching
                        if display_type and not display_type_2:
                            print("▶ Running flow for Display Type only")

                            el1 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((By.XPATH, "//android.widget.ScrollView/android.widget.EditText"))
                            )
                            el1.send_keys("1")

                            el2 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((By.XPATH, "//android.widget.ScrollView/android.view.View[1]/android.widget.EditText/android.view.View"))
                            )
                            el2.click()

                            el3 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((By.XPATH, "//android.widget.TextView[@text='Cardboard']"))
                            )
                            el3.click()

                            el4 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((By.XPATH, "//android.widget.ScrollView/android.view.View[2]/android.widget.EditText/android.view.View"))
                            )
                            el4.click()

                            el5 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((By.XPATH, "//android.widget.TextView[@text='Yes']"))
                            )
                            el5.click()

                            el6 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((By.XPATH, "//android.widget.ScrollView/android.view.View[3]/android.widget.EditText/android.view.View"))
                            )
                            el6.click()

                            el7 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((By.XPATH, "//android.widget.TextView[@text='The POP has no Theme']"))
                            )
                            el7.click()

                            el8 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((By.XPATH,
                                    "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.widget.Button"))
                            )
                            el8.click()

                        else:
                            print("⚠ Display Type not available → Short flow")
                            el3 = WebDriverWait(context.driver, timeout).until(
                                EC.presence_of_element_located((By.CLASS_NAME, "android.widget.EditText"))
                            )
                            el3.send_keys("1")

                            el4 = WebDriverWait(context.driver, timeout).until(
                                EC.element_to_be_clickable((By.XPATH,
                                    "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.widget.Button"))
                            )
                            el4.click()

                    except Exception as e:
                        print(f"❌ Unexpected error: {e}")
                    continue

                # ✅ Special count = 0
                print("✅ Special count reached 0")
                if success_count > 0:
                    el1 = WebDriverWait(context.driver, timeout).until(
                        EC.element_to_be_clickable((By.XPATH,
                            "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[5]"))
                    )
                    el1.click()

                    el2 = WebDriverWait(context.driver, timeout).until(
                        EC.element_to_be_clickable((By.XPATH,
                            "//android.view.ViewGroup/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button"))
                    )
                    el2.click()
                    break

                # ✅ Retry if Success == 0
                print("⚠ Success count is 0, retrying...")
                random_number = str(random.randint(100001, 999999))

                el1 = WebDriverWait(context.driver, timeout).until(
                    EC.element_to_be_clickable((By.XPATH,
                        "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]"))
                )
                el1.click()

                el2 = WebDriverWait(context.driver, timeout).until(
                    EC.element_to_be_clickable((By.XPATH,
                        "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]/android.view.View[4]"))
                )
                el2.click()

                el4 = WebDriverWait(context.driver, timeout).until(
                    EC.presence_of_element_located((By.CLASS_NAME, "android.widget.EditText"))
                )
                el4.send_keys(random_number)

                el5 = WebDriverWait(context.driver, timeout).until(
                    EC.element_to_be_clickable((By.CLASS_NAME, "android.widget.Button"))
                )
                el5.click()

                while success_count == 0:
                    Sucess_count = WebDriverWait(context.driver, timeout).until(
                        EC.presence_of_element_located((By.XPATH, "//android.widget.TextView[starts-with(@text,'Success')]"))
                    )
                    success_count = int(re.findall(r'\d+', Sucess_count.text)[0])
                    print(f"Retry success check: {success_count}")

                    if success_count > 0:
                        print("✅ Success finally achieved.")
                        el1 = WebDriverWait(context.driver, timeout).until(
                            EC.element_to_be_clickable((By.XPATH,
                                "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[5]"))
                        )
                        el1.click()

                        el2 = WebDriverWait(context.driver, timeout).until(
                            EC.element_to_be_clickable((By.XPATH,
                                "//android.view.ViewGroup/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button"))
                        )
                        el2.click()
                        break
                    else:
                        print("❌ Still no success, retrying...")
                break

    except Exception as e:
        print("Error in confirm_android():", str(e))





@then("I will select random sp available store")
def select_store(context, timeout=500, scroll_threshold=3, target_strings=["SP Training Hot Cereal(8785)"],expected_store=["TARGET"]):
    # List of store XPaths (can be adjusted for your app)
    stores_xpaths = [
        "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[1]/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView[1]",
        "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView[1]",
        "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[3]/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView[1]"
    ]
    child_xpaths = [
        '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.RelativeLayout[1]/android.widget.RelativeLayout/android.widget.TextView',
        '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.RelativeLayout[2]/android.widget.RelativeLayout/android.widget.TextView',
        '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.RelativeLayout[3]/android.widget.RelativeLayout/android.widget.TextView'
    ]
    stores_checked = 0  # Track the number of stores checked
    while True:
        stores_found = False  # Flag to track if a store matching the target is found
        # Loop through the store XPaths
        for store_xpath in stores_xpaths:
            try:
                # Wait for the store element to be clickable
                store_element = WebDriverWait(context.driver, timeout).until(
                    EC.element_to_be_clickable((By.XPATH, store_xpath)))
                store_element.click()
                textt = store_element.text
                print("store name :", textt)

                target_found = False
                # Check for target strings in the store's child elements
                for child_xpath in child_xpaths:
                    try:
                        # Check if the child element is present
                        text_element = WebDriverWait(context.driver, 1).until(
                            EC.presence_of_element_located((By.XPATH, child_xpath)))
                        # If child element is found, check its text
                        text_value = text_element.text
                        print(f"Found child element: {text_value}")
                        if text_value in target_strings and textt in expected_store:
                            print(f"Found '{target_strings}' in child XPath: {child_xpath}, clicking on it.")
                            text_element.click()
                            target_found = True  # Mark that the target has been found
                            return  # Exit the loop once we find the target in one of the child XPaths
                    except Exception as e:
                        # If child element is not found, skip to the next child_xpath
                        print(f"Child element not available for XPath: {child_xpath}. Skipping.")
                        continue
                    # If no child element contains the target string, click on the store element
                store_element = WebDriverWait(context.driver, timeout).until(
                    EC.element_to_be_clickable((By.XPATH, store_xpath)))
                store_element.click()
                # If target is not found in any of the child XPaths, log and continue
                print(f"Target not found in store at XPath: {store_xpath}")
            except Exception as e:
                print(f"Error processing store at {store_xpath}: {e}")
                continue  # Continue with the next store XPath if an error occurs
        # If no store with the target string was found, scroll up and reload the store list
        if not stores_found:
            print("None of the stores matched the target. Scrolling up...")
            scroll_distance = 700  # Distance to scroll
            screen_size = context.driver.get_window_size()
            # Define the start and end positions for the swipe action
            start_x = screen_size['width'] / 2
            start_y = screen_size['height'] * 0.8  # Start near the bottom
            end_y = start_y - scroll_distance  # Scroll upwards by the specified distance
            # Perform the swipe action (scrolling)
            context.driver.swipe(start_x, start_y, start_x, end_y, 300)
            print("Successfully Scrolled Page Up")
            # Wait for new stores to load (based on the first store XPath)
            WebDriverWait(context.driver, timeout).until(
                EC.presence_of_element_located((By.XPATH, stores_xpaths[0])))
            stores_checked += 1
            # After a set number of scrolls, restart from the first store XPath
            if stores_checked >= scroll_threshold:
                print(f"Scrolled {stores_checked} times, restarting from the first store XPath.")
                stores_checked = 0  # Reset counter to recheck the stores
        else:
            print("Store matching target found, exiting function.")
            break  # Exit the loop if the target store is found











































































































































































































































































