from hamcrest.core.matcher import Matcher
from hamcrest import *
from fileutils import fileutils
from typing import TypeVar

T = TypeVar("T")


def custom_assert(actual: T, matcher: Matcher[T], reason: str, context):
    try:
        assert_that(actual, matcher, reason)
    except Exception as error:
        print("Error occurred in custom assert method", error)
        fileutils_obj = fileutils()
        fileutils.write_failure_and_error_to_outputfile(fileutils_obj, context, error)




