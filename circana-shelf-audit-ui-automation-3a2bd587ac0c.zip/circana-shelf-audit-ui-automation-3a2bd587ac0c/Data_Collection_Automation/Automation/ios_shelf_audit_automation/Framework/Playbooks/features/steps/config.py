import os
DeviceName = "0J739301222179AE"
LocalHost = "http://localhost:4723/wd/hub"
platformName = "Android"
AndroidVersion = "14"
Testing_image = "C:\\Users\\binduram.cv\\Data_collection_Automation\\Data_Collection_Automation\\Automation\\shelf_audit_automation\\Framework\\Playbooks\\features\steps\\Testing_image.png"
Barcode_image = "C:\\Users\\binduram.cv\\Data_collection_Automation\\Data_Collection_Automation\\Automation\\shelf_audit_automation\\Framework\\Playbooks\\features\steps\\Barcode.png"
Testing_image_2 = "C:\\Users\\binduram.cv\\Data_collection_Automation\\Data_Collection_Automation\\Automation\\shelf_audit_automation\\Framework\\Playbooks\\features\steps\\Testing_image_2.jpg"
Video_recording_path ="C:\\Users\\binduram.cv\\Data_collection_Automation\\Data_Collection_Automation\\Automation\\shelf_audit_automation\\Framework\\Playbooks\\features\steps\\Videos\\"
home_path = "C:\\Users\\binduram.cv\\Data_Collection_Automation\\Data_Collection_Automation\\Automation\\shelf_audit_automation"
Testing_image_4 = "C:\\Users\\binduram.cv\\Data_collection_Automation\\Data_Collection_Automation\\Automation\\shelf_audit_automation\\Framework\\Playbooks\\features\steps\\Testing_image_4.png"

package_name = "com.iri.collection"

head_spin_url = "https://dev-us-sny-8.headspin.io:7010/v0/2c48a91cfdd14d30864178f07e665e90/wd/hub"

# head_spin_url = os.getenv("HEADSPIN_URL", "")
