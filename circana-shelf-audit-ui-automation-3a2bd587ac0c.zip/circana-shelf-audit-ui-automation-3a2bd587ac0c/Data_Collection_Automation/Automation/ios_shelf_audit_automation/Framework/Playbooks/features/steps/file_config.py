# from config import home_path
# log_reference_file_path = home_path + '/logs/'
# future_test_case_result_file_name = log_reference_file_path + 'TestResults.txt'
# future_result_case_file_name = log_reference_file_path + 'FailedTestcases_Info.txt'
# output_log_file = log_reference_file_path + 'output_logs.log'
#
