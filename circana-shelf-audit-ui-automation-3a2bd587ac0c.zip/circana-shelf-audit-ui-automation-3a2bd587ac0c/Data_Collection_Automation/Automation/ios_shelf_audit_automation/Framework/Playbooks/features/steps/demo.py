# # import base64
# # import os.path
# #
# # from appium import webdriver
# from config import *
# # from behave import *
# # from selenium.webdriver.common.by import By
# # import time
# # from appium import webdriver
# # from config import *
# # from behave import given, when, then
# # from selenium.webdriver.common.by import By
# # from selenium.webdriver.support.ui import WebDriverWait
# # from selenium.webdriver.support import expected_conditions as EC
# #
# # from datetime import datetime
# #
# # today_day = datetime.now().day
# # print(today_day)
# # # desired_caps = {
# # #     "automationName": "UiAutomator2",
# # #     "platformName": platformName,
# # #     "platformVersion": AndroidVersion,
# # #     "deviceName": DeviceName,
# # #     "appPackage": "com.circana.shelfaudit",
# # #     "appActivity": "com.circana.shelfaudit.MainActivity",
# # #     "noReset": True
# # # }
# # # driver = webdriver.Remote(LocalHost, desired_caps)
# # # time.sleep(5)
# # # driver.start_recording_screen()
# # # chose_week = driver.find_element(By.XPATH, "//android.view.ViewGroup[starts-with(@content-desc, "
# # #                                            "'Scanscape Week')]")
# # # chose_week.click()
# # # time.sleep(2)
# # # chose_week = driver.find_element(By.XPATH,
# # #                                  '//android.view.ViewGroup[@content-desc="Scanscape Week 2360 (18th Nov - 24th Nov)"]/android.widget.TextView')
# # # chose_week.click()
# # # time.sleep(2)
# # # video_data = driver.stop_recording_screen()
# # #
# # #
# # # video_name = driver.current_activity + time.strftime("%Y_%m_%d_%H%M%S")
# # #
# # # filepath = os.path.join(Video_recording_path, video_name+".mp4")
# # #
# # # with open(filepath,"wb") as vd:
# # #     vd.write(base64.b64decode(video_data))
# # import re
# #
# # a = "Failed (13)"
# #
# # b = re.findall(r'\d+' , a)
# #
# # c = [int(num) for num in b]
# # print(str(v[0]))
#
# # a = 13
# #
# # for i in range(13):
# #     print("hello")
#
#
# # from appium import webdriver
# # from appium.webdriver.common.touch_action import TouchAction
# #
# # # Desired capabilities
# # desired_caps = {
# #     "platformName": "Android",  # Or "iOS" for iOS devices
# #     "deviceName": "YourDeviceName",
# #     "app": "YourAppPath",  # Path to your app or package
# #     # Add other desired capabilities as needed
# # }
# #
# # # Start the Appium session
# # driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)
# #
# # # Locate the text box element
# # text_box = driver.find_element_by_id("your_text_box_id")  # Use the appropriate locator
# #
# # # Get the location and size of the text box
# # start_x = text_box.location['x'] + (text_box.size['width'] // 2)  # Center of the text box
# # start_y = text_box.location['y'] + (text_box.size['height'] // 2)  # Center of the text box
# #
# # # Define the target position (move to the left)
# # end_x = start_x - 200  # Adjust the value to set how far left you want to move
# # end_y = start_y  # Keep the same vertical position
# #
# # # Perform the drag-and-drop action
# # action = TouchAction(driver)
# # action.press(x=start_x, y=start_y).wait(500).move_to(x=end_x, y=end_y).release().perform()
# #
# # # Quit the driver (if you're done)
# # driver.quit()
#
# # import random
# #
# # # Generate a random number between 100001 and 999999
# # random_number = random.randint(100001, 999999)
# #
# # print(f"Random number: {random_number}")
#
# # Upc_number = ['806478', '184184', '680662', '589750']
# #
# #
# # formatted_number = [str(num).zfill(12) for num in Upc_number]
# #
# # print("form", formatted_number)
#
# #
# # import subprocess
# # from appium import webdriver
# #
# #
# # desired_caps = {
# #         "automationName": "UiAutomator2",
# #         "platformName": platformName,
# #     #     "platformVersion": AndroidVersion,
# #         "deviceName": DeviceName,
# #     #     "appPackage": "com.iri.collection",
# #     #     "appActivity": "com.iri.collection.MainActivity",
# #         "newCommandTimeout": "3600",
# #         "noReset": True
# #     }
# # driver = webdriver.Remote(LocalHost, desired_caps)
# #
# # command = f"adb shell monkey -p com.iri.collection -c android.intent.category.LAUNCHER 1"
# # subprocess.run(command, shell=True, check=True)
# # Upc_count = 10
# # failed_count = 2
# #
# # Upc_count = Upc_count - failed_count
# #
# # Upc_count = Upc_count+1
# #
# # print(Upc_count)
#
#
# a = ['000000531268', '000000406234', '000000750212', '000000577204', '000000483689', '000000987979', '000000263580', '000000872757', '000000859558', '000000736077', '000000230045', '000000564786', '000000971250', '000000995261']
# b  = ['000000531268', '000000406234', '000000750212', '000000577204', '000000483689', '000000987979', '000000263580', '000000872757', '000000859558', '000000736077', '000000230045', '000000564786', '000000971250', '000000995261']
#
# if sorted(a) == sorted(b):
#     print("same")
# else:
#     print("failed")
